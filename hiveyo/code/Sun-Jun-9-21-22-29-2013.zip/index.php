<?php
include_once('./class.php');
$obj = new hive;
$obj->username = "root";
$obj->password="";
$obj->servername="localhost";
$obj->dbname="hiveyox";
$obj->connect();
echo <<< THEHTML
<html>
<head>
<script>
  var drawUpArrow = function( id, width, height, colour ) {
        var canvas = document.getElementById('canvas-'+id);
        var ctx = canvas.getContext('2d');

        var xCoord=width/2;
        var yCoord=height/2;

        ctx.beginPath();
        ctx.moveTo(xCoord,0);
        ctx.lineTo(0,yCoord);
        ctx.lineTo(xCoord/2,yCoord);
        ctx.lineTo(xCoord/2,yCoord*2);
        ctx.lineTo(xCoord+xCoord/2,yCoord*2);
        ctx.lineTo(xCoord+xCoord/2,yCoord);
        ctx.lineTo(xCoord*2,yCoord);
        ctx.closePath();

        ctx.fillStyle = colour;
        ctx.fill();

        ctx.strokeStyle = colour;
        ctx.stroke();
    }
    var drawDownArrow = function( id, width, height, colour ) {
        var canvas = document.getElementById('canvas-'+id);
        var ctx = canvas.getContext('2d');

        var xCoord=width/2;
        var yCoord=height/2;

        ctx.beginPath();
        ctx.moveTo(xCoord,yCoord*2);
        ctx.lineTo(0,yCoord);
        ctx.lineTo(xCoord*2,yCoord);
        //ctx.lineTo(xCoord/2,yCoord);
        //ctx.lineTo(xCoord/2,0);
        //ctx.lineTo(xCoord+xCoord/2,0);
        //ctx.lineTo(xCoord+xCoord/2,yCoord);
        //ctx.lineTo(xCoord*2,yCoord);
        ctx.closePath();

        ctx.fillStyle = colour;
        ctx.fill();

        ctx.strokeStyle = colour;
        ctx.stroke();
    }
</script>
<link rel="stylesheet" href="hive_style.css" type="text/css" />
<title>Hiveyo</title>
</head>
<body>
<div id="header">
<h1 class="header">
Hive
<canvas onclick="alert('dropdown')" id='canvas-1' width='40' height='40'>
        If you see this that means that your browser doesn't support
	the cool new HTML5 canvas elements.  Boy are <em>you</em>
        missing out!  You might want to upgrade.
</canvas>
 <script>
      var thecanvas=document.getElementById("canvas-1");
      if(thecanvas){
	  var ctx=thecanvas.getContext("2d");
	  if(ctx){
	  drawDownArrow(1,40,40,"black");
	  }else{
	      alert("no context!  Can't go on");
	  }
      } else {
	  alert("Couldn't find the canvas!");
      }
    </script>
</h1>
</div>
<div id="content">
THEHTML;
//echo $obj->images();
echo <<< THEFOOTER
</div>
</body>
</html>
THEFOOTER;
?>